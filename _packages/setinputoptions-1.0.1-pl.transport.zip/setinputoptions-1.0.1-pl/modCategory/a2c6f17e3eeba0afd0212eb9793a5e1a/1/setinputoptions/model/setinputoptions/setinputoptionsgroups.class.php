<?php
/**
 * @package setinputoptions
 */
class SetInputOptionsGroups extends xPDOSimpleObject {}
?>