<?php
/**
 * @package setinputoptions
 */
class SetInputOptionsItem extends xPDOSimpleObject {}