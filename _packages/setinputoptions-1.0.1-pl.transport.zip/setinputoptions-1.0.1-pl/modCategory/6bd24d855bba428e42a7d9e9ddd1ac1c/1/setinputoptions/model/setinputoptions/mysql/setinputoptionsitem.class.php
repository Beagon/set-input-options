<?php
/**
 * @package setinputoptions
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/setinputoptionsitem.class.php');
class SetInputOptionsItem_mysql extends SetInputOptionsItem {}
?>