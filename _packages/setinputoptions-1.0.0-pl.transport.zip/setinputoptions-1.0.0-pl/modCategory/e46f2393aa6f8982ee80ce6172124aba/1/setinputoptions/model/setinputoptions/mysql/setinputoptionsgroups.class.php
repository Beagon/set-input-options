<?php
/**
 * @package setinputoptions
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/setinputoptionsgroups.class.php');
class SetInputOptionsGroups_mysql extends SetInputOptionsGroups {}
?>