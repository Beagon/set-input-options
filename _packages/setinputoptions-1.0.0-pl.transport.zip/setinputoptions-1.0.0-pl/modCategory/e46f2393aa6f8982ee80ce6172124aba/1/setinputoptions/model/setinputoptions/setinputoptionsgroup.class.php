<?php
/**
 * @package setinputoptions
 */
class SetInputOptionsGroup extends xPDOSimpleObject {}
?>