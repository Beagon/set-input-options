<?php
/**
 * @package setinputoptions
 */
$xpdo_meta_map['SetInputOptionsGroups']= array (
  'package' => 'setinputoptions',
  'version' => '0.1',
  'table' => 'setinputoptions_Groups',
  'extends' => 'xPDOSimpleObject',
  'fields' => 
  array (
    'name' => NULL,
  ),
  'fieldMeta' => 
  array (
    'name' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '100',
      'phptype' => 'string',
      'null' => false,
    ),
  ),
);
