<?php
/**
 * @package setinputoptions
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/setinputoptionsinputoptions.class.php');
class SetInputOptionsInputOptions_mysql extends SetInputOptionsInputOptions {}
?>