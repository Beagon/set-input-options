<?php
/**
 * @package setinputoptions
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/setinputoptionsinputoption.class.php');
class SetInputOptionsInputOption_mysql extends SetInputOptionsInputOption {}
?>