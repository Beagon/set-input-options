<?php
/**
 * @package setinputoptions
 */
class SetInputOptionsInputOption extends xPDOSimpleObject {}
?>