<?php
/**
 * @package setinputoptions
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/setinputoptionsgroup.class.php');
class SetInputOptionsGroup_mysql extends SetInputOptionsGroup {}
?>