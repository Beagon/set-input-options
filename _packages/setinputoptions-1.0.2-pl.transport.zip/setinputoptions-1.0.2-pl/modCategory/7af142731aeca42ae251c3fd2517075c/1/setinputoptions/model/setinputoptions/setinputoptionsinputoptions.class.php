<?php
/**
 * @package setinputoptions
 */
class SetInputOptionsInputOptions extends xPDOSimpleObject {}
?>